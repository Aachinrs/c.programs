/*Given three values, write a program to read three values 
from keyboard and print out the largest of them.
*/
#include<stdio.h>
int main ()
{
    int a,b,c;
    printf("enter the first integer a:");
    scanf("%d",&a);
    printf("enter the second integer b:");
    scanf("%d",&b);
    printf("enter the third integer c:");
    scanf("%d",&c);
    if (a>b)
    {
        if (a>c)
        {
            printf("%d is the largest",a);
        }
        else 
        {
            printf("%d is the largest",c);
        }
    }
    else
    {
        if (b>c)
        {
            printf("%d is the largest",b);
        }
        else
        {
            printf("%d is the largest",c);
        }
    }
}